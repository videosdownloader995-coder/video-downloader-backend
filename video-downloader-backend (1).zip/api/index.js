
const express = require('express');
const app = express();

app.use('/youtube', require('../controllers/youtube'));
app.use('/tiktok', require('../controllers/tiktok'));
app.use('/instagram', require('../controllers/instagram'));
app.use('/facebook', require('../controllers/facebook'));

module.exports = app;
