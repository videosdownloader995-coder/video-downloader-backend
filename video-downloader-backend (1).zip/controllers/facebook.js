import express from "express";
import axios from "axios";
import cheerio from "cheerio";

const router = express.Router();

router.get("/", async (req, res) => {
  try {
    const link = req.query.url;
    if (!link) return res.json({ error: "URL required" });

    const { data } = await axios.get(link);
    const $ = cheerio.load(data);

    const video = $('meta[property="og:video:url"]').attr("content");

    res.json({ success: true, video });
  } catch (err) {
    res.json({ error: err.message });
  }
});

export default router;
