import express from "express";
import axios from "axios";
import cheerio from "cheerio";

const router = express.Router();

router.get("/", async (req, res) => {
  try {
    const link = req.query.url;
    if (!link) return res.json({ error: "URL required" });

    const html = await axios.get(link);
    const $ = cheerio.load(html.data);

    const video = $('meta[property="og:video"]').attr("content");
    const image = $('meta[property="og:image"]').attr("content");

    res.json({ success: true, video, image });
  } catch (err) {
    res.json({ error: err.message });
  }
});

export default router;
