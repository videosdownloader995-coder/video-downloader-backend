import express from "express";
import TikTokScraper from "tiktok-scraper";

const router = express.Router();

router.get("/", async (req, res) => {
  try {
    const url = req.query.url;
    if (!url) return res.json({ error: "URL required" });

    const data = await TikTokScraper.getVideoMeta(url);

    res.json({
      success: true,
      video: data?.collector?.[0]?.videoUrlNoWaterMark || data?.collector?.[0]?.videoUrl
    });
  } catch (err) {
    res.json({ error: err.message });
  }
});

export default router;
