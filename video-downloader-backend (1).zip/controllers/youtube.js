import express from "express";
import ytdl from "ytdl-core";

const router = express.Router();

router.get("/", async (req, res) => {
  try {
    const videoURL = req.query.url;
    if (!videoURL) return res.json({ error: "URL required" });

    const info = await ytdl.getInfo(videoURL);

    const formats = info.formats.map(f => ({
      quality: f.qualityLabel,
      type: f.container,
      url: f.url
    }));

    res.json({ success: true, formats });
  } catch (err) {
    res.json({ error: err.message });
  }
});

export default router;
